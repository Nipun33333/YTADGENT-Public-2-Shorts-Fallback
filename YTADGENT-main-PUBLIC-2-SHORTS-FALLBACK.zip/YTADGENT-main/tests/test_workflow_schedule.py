from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / ".github" / "workflows" / "daily-short.yml"
CONFIG = ROOT / "config.py"
ENV_EXAMPLE = ROOT / ".env.example"
PIPELINE = ROOT / "pipeline.py"


def test_workflow_runs_two_daily_public_upload_attempts():
    text = WORKFLOW.read_text(encoding="utf-8")
    assert text.count('cron: "30 13 * * *"') == 1
    assert "VIDEO_PRIVACY: public" in text
    assert "Generate and upload two Shorts sequentially" in text
    assert "for slot in 1 2" in text
    assert "SKIP_UPLOAD_IN_CI" not in text
    assert "SKIP_YOUTUBE_UPLOAD" not in text


def test_public_upload_and_approval_disabled_are_defaults():
    config = CONFIG.read_text(encoding="utf-8")
    env_example = ENV_EXAMPLE.read_text(encoding="utf-8")
    assert 'VIDEO_PRIVACY = "public"' in config
    assert "REQUIRE_HUMAN_APPROVAL" not in config
    assert "VIDEO_PRIVACY=public" in env_example
    assert "REQUIRE_HUMAN_APPROVAL" not in env_example


def test_production_runs_are_serialized():
    text = WORKFLOW.read_text(encoding="utf-8")
    assert "concurrency:" in text
    assert "group: daily-youtube-public-shorts" in text
    assert "cancel-in-progress: false" in text


def test_pipeline_uploads_directly_and_has_media_fallback():
    text = PIPELINE.read_text(encoding="utf-8")
    assert "create_fallback_media_map" in text
    assert "start_review_server" not in text
    assert "stage_video" not in text
    assert "upload_to_youtube(script, video_path)" in text
