"""Semantic selector for current US trending-topic explanations.

This module has no fixed niche gate. Candidates come from broad current US YouTube
signals and Gemini selects one current subject that can support an explanation,
breakdown, context, analysis, or recap video.
"""
from __future__ import annotations

import json
import re
from typing import Any

from agents.gemini_client import generate
import config


CONTENT_MODE = "US_TREND_EXPLANATION"
ALLOWED_CONTENT_TYPES = {
    "EXPLAINER",
    "BREAKDOWN",
    "ANALYSIS",
    "NEWS_EXPLAINER",
    "CONTEXT",
    "TIMELINE",
    "HOW_IT_WORKS",
    "RECAP",
    "TREND_EXPLAINER",
}


def evaluate_gaming_relevance(title: str, summary: str = "", category_id: str = "") -> dict[str, Any]:
    """Return a conservative gaming relevance decision without replacing semantic selection.

    Strong gaming-specific phrases are preferred over the generic word "game".
    Exclusions only reject a candidate when no gaming signal is present, avoiding
    false negatives for games that discuss politics, celebrities, or finance.
    """
    if not getattr(config, "STRICT_NICHE_MODE", True):
        return {"approved": True, "score": 1.0, "reason": "Strict niche mode disabled"}

    text = f"{title} {summary}".lower()
    text = re.sub(r"[^a-z0-9+#]+", " ", text)
    allowed = getattr(config, "NICHE_CONFIG", {}).get("allowed_keywords", [])
    matches = [kw for kw in allowed if re.search(r"(?<![a-z0-9])" + re.escape(kw.lower()) + r"(?![a-z0-9])", text)]
    # YouTube category 20 is Gaming, but category is only a supporting signal.
    if str(category_id).strip() == "20":
        matches.append("youtube gaming category")

    if matches:
        score = min(1.0, 0.70 + 0.10 * (len(set(matches)) - 1))
        return {"approved": score >= getattr(config, "MIN_RELEVANCE_SCORE", 0.60), "score": score,
                "reason": "Gaming signals: " + ", ".join(dict.fromkeys(matches[:5]))}

    excluded = getattr(config, "NICHE_CONFIG", {}).get("excluded_keywords", [])
    for keyword in excluded:
        if re.search(r"(?<![a-z0-9])" + re.escape(keyword.lower()) + r"(?![a-z0-9])", text):
            return {"approved": False, "score": 0.0, "reason": f"Unrelated trend: {keyword}"}
    return {"approved": False, "score": 0.20, "reason": "No recognizable gaming relevance signal"}


def clean_json_response(raw: str) -> dict[str, Any]:
    raw = (raw or "").strip()
    raw = re.sub(r"^```(?:json)?", "", raw, flags=re.I).strip()
    raw = re.sub(r"```$", "", raw).strip()
    match = re.search(r"\{[\s\S]*\}", raw)
    if not match:
        raise ValueError("Gemini returned no valid JSON object.")
    return json.loads(match.group())


def build_selection_prompt(candidates: list[dict], channel_description: str = "") -> str:
    rows = []
    for item in candidates:
        rows.append(json.dumps({
            "candidate_id": item.get("video_id"),
            "title": item.get("title", ""),
            "description": item.get("description", "")[:300],
            "channel": item.get("channel", ""),
            "category_id": item.get("category_id", ""),
            "views": item.get("views", 0),
            "likes": item.get("likes", 0),
            "comments": item.get("comments", 0),
            "trend_score": item.get("trend_score", 0),
            "published_at": item.get("published_at", ""),
        }, ensure_ascii=False))

    return f"""You are the current-US-gaming-trend selector for a gaming explanation channel.

CHANNEL POSITIONING:
{channel_description}

GOAL:
Select ONE genuinely current, high-signal US GAMING candidate from the list.
The selected candidate becomes the immutable subject for the entire pipeline.
Prefer gaming news, lore, mechanics, updates, esports, speedruns, glitches,
player culture, or game design. Do not switch to an unrelated trend. The list
has already passed a conservative gaming-relevance gate; use semantic judgment
for the final selection.

SELECTION RULES:
- Choose only a candidate_id present in the supplied list.
- Prefer strong current trend signals: recency, view velocity, engagement, and
  broad US interest.
- Prefer candidates that can be explained, contextualized, analyzed, or broken
  down in a short video.
- A raw clip/performance is acceptable when the surrounding subject itself is
  explainable; do not invent a different topic.
- Category metadata may be used only as supporting context; never prioritize or reject a candidate because of its category.
- Never invent a candidate, entity, or event.
- If all candidates are unsafe or unusable, return candidate_id as null.

CANDIDATES:
""" + "\n".join(rows) + """

Return ONLY JSON:
{
  "candidate_id": "existing candidate_id or null",
  "content_type": "EXPLAINER | BREAKDOWN | ANALYSIS | NEWS_EXPLAINER | CONTEXT | TIMELINE | HOW_IT_WORKS | RECAP | TREND_EXPLAINER",
  "content_domain": "GENERAL_TREND",
  "content_angle": "specific explanation angle tied directly to the selected candidate",
  "why_it_fits": "brief reason this subject is worth explaining now",
  "confidence": 0.0
}
"""


def select_semantic_candidate(candidates: list[dict], channel_description: str = "") -> dict[str, Any]:
    if not candidates:
        raise ValueError("No candidates supplied to trend selector.")

    if getattr(config, "STRICT_NICHE_MODE", True):
        eligible = []
        for item in candidates:
            relevance = evaluate_gaming_relevance(
                str(item.get("title", "")),
                str(item.get("description", "")),
                str(item.get("category_id", "")),
            )
            if relevance["approved"]:
                candidate = dict(item)
                candidate["gaming_relevance_score"] = relevance["score"]
                candidate["gaming_relevance_reason"] = relevance["reason"]
                eligible.append(candidate)
        if not eligible:
            raise RuntimeError("No usable current US trend candidate matched the gaming niche criteria.")
        candidates = eligible

    prompt = build_selection_prompt(candidates, channel_description)
    try:
        raw = generate(
            prompt,
            timeout_seconds=getattr(config, "GEMINI_SELECTION_TIMEOUT_SECONDS", 30),
            max_models=getattr(config, "GEMINI_SELECTION_MAX_MODELS", 6),
        )
    except TypeError as exc:
        if "unexpected keyword argument" not in str(exc):
            raise
        raw = generate(prompt)

    result = clean_json_response(raw)
    candidate_id = result.get("candidate_id")
    if not candidate_id:
        raise RuntimeError("No usable current US trend candidate matched the explanation criteria.")

    lookup = {str(x.get("video_id")): x for x in candidates}
    selected = lookup.get(str(candidate_id))
    if selected is None:
        raise ValueError("Trend selector returned an unknown candidate_id.")

    content_type = str(result.get("content_type", "EXPLAINER")).upper().strip()
    if content_type not in ALLOWED_CONTENT_TYPES:
        content_type = "EXPLAINER"

    selected = dict(selected)
    selected.update({
        "content_type": content_type,
        "content_domain": "GENERAL_TREND",
        "content_angle": str(result.get("content_angle", "")).strip(),
        "why_it_fits": str(result.get("why_it_fits", "")).strip(),
        "semantic_confidence": float(result.get("confidence", 0) or 0),
    })
    return selected


def validate_manual_topic(topic: str) -> dict[str, Any]:
    """Validate a user-supplied topic against the configured gaming niche."""
    topic = topic.strip()
    if not topic:
        raise ValueError("Manual topic cannot be empty.")
    relevance = evaluate_gaming_relevance(topic)
    if not relevance["approved"]:
        raise ValueError(
            "Manual topic does not match the gaming niche. Include a clear game, "
            "gaming mechanic, update, esports, lore, or game-culture subject. "
            f"Reason: {relevance['reason']}"
        )
    return {
        "video_id": "manual",
        "title": topic,
        "description": "User-supplied topic.",
        "channel": "manual",
        "category_id": "",
        "views": 0,
        "trend_score": 0,
        "published_at": "",
        "content_type": "EXPLAINER",
        "content_domain": "GENERAL_TREND",
        "content_angle": "Explain the selected topic clearly and directly.",
        "semantic_confidence": 1.0,
    }
