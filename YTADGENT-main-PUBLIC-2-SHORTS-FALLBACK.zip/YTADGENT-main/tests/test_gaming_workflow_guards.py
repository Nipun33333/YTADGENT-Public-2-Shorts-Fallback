from pathlib import Path

import config

ROOT = Path(__file__).resolve().parents[1]
from agents.niche import evaluate_gaming_relevance


def test_gaming_topic_passes_relevance_gate():
    result = evaluate_gaming_relevance("Valve patches Counter-Strike sub-tick hitbox alignment")
    assert result["approved"] is True
    assert result["score"] >= 0.60


def test_unrelated_celebrity_topic_is_rejected():
    result = evaluate_gaming_relevance("Celebrity gossip and red carpet relationship drama")
    assert result["approved"] is False


def test_human_approval_gate_is_removed():
    uploader_source = (ROOT / "uploader" / "youtube.py").read_text(encoding="utf-8")
    pipeline_source = (ROOT / "pipeline.py").read_text(encoding="utf-8")
    assert "verify_staged_approval" not in uploader_source
    assert "start_review_server" not in pipeline_source
    assert "approval_id" not in uploader_source


def test_public_privacy_is_default():
    config_source = (ROOT / "config.py").read_text(encoding="utf-8")
    assert 'VIDEO_PRIVACY = "public"' in config_source


def test_fallback_media_map_creates_visuals(tmp_path):
    from video.stock import create_fallback_media_map
    script = {
        "video_type": "shorts",
        "topic": "Counter-Strike patch update",
        "sections": [
            {"id": 1, "title": "Patch changes"},
            {"id": 2, "title": "Why players care"},
        ],
    }
    result = create_fallback_media_map(script, str(tmp_path), reason="test")
    assert set(result) == {1, 2}
    for paths in result.values():
        assert len(paths) == 1
        assert Path(paths[0]).is_file()


def test_media_provider_exceptions_return_empty_for_next_fallback():
    from video.stock import _safe_media_fetch
    def broken_provider(*args, **kwargs):
        raise RuntimeError("provider down")
    assert _safe_media_fetch(broken_provider, "test provider") == []
