<div align="center">

<img src="docs/screenshots/banner.png" alt="YouTube AI Agent Studio" width="100%">

# 🎬 YTAGENT — Gaming Trend Explanation Studio

**An AI pipeline for current US gaming news, lore, mechanics, updates, esports, and gaming-culture explainers. Gaming relevance is checked before semantic selection. The pipeline uploads Shorts directly as public videos, with multi-provider media fallback.**

[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=flat-square&logo=python&logoColor=white)](https://python.org)
[![Gemini](https://img.shields.io/badge/AI-Google%20Gemini-4285F4?style=flat-square&logo=google&logoColor=white)](https://aistudio.google.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)
[![Free Tier](https://img.shields.io/badge/Cost-$0%20per%20video-brightgreen?style=flat-square)](SETUP.md)
[![Stars](https://img.shields.io/github/stars/raunakpatil/youtube-agentic-ai-studio?style=flat-square)](https://github.com/raunakpatil/youtube-agentic-ai-studio/stargazers)

[**Quick Start**](#-quick-start) · [**Features**](#-features) · [**Pipeline**](#️-how-it-works) · [**Setup Guide**](SETUP.md) · [**FAQ**](#-faq)

</div>

---

## ✨ Features

| Feature | Details |
|---|---|
| 🧠 **Dynamic Discovery** | Current US YouTube signals + gaming relevance gate + semantic Gemini selection |
| ✍️ **Script Writing** | Full narrated script with hook, sections, and CTA — in JSON |
| 🎙️ **Free Voice** | Microsoft Edge TTS (no API key, no cost, word-level timing) |
| 🎞️ **Topic-Relevant Footage** | Searches video footage and validates relevance against the selected subject |
| 🎞️ **Animated Video** | Ken Burns zoom, smooth crossfades, captions, progress bars |
| 📱 **Shorts Support** | Generates vertical 9:16 Shorts alongside the main video |
| 🔁 **Media Fallback** | Google Videos → Pexels Videos → Google Images → Pexels Images → generated local topic card |
| 🌐 **Direct Public Upload** | No human approval gate; YouTube privacy defaults to public |
| 🔄 **Fast Model Fallback** | Preferred Gemini model first; fallback only after a real request fails |
| 🎵 **Background Music** | Drop MP3s in `music library/` — auto-looped to fit video length |

---

## 🖥️ Screenshots

| | |
|---|---|
| ![Main GUI](docs/screenshots/gui_main.png) | ![Settings](docs/screenshots/gui_settings.png) |
| **Main dashboard** — generate videos with one click | **Settings panel** — configure every aspect |
| ![Banner](docs/screenshots/banner.png) | |
| **Pipeline overview** | |

---

## 🎬 Live Example — Built With This Tool

This repo powers **[Eldritch Lore](https://www.youtube.com/@EldritchLore)** — a real YouTube channel running entirely on this pipeline.

[![YouTube Subscribers](https://img.shields.io/youtube/channel/subscribers/UCqDCtCHo22_6KtJ0rkDFG5g?style=for-the-badge&logo=youtube&label=Eldritch%20Lore&color=FF0000)](https://www.youtube.com/@EldritchLore)

> "Why a selected current trend matters, what happened, the key context, and what viewers need to know."
> Every video on this channel was researched, scripted, narrated, and uploaded using exactly this code.

**[→ See what this tool can actually produce](https://www.youtube.com/@TheFracturedTimelines)**

---

## ⚡ Quick Start

```bash
# 1. Clone
git clone https://github.com/raunakpatil/youtube-agentic-ai-studio.git
cd youtube-agentic-ai-studio

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your API keys (copy and edit .env.example)
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY and PEXELS_API_KEY

# 4. Run the GUI
python gui.py
# → Opens at http://localhost:7842

# — OR — run the pipeline directly from the terminal
python pipeline.py
```

> **First run?** Read the full [Setup Guide](SETUP.md) — it takes about 10 minutes.

---

## 🏗️ How It Works

The pipeline runs 6 sequential phases:

```
python pipeline.py  ──►  Research  ──►  Script  ──►  Narration
                                                          │
              YouTube ◄── Public Upload ◄── Video ◄──┘
```

| Phase | Agent | What it does |
|---|---|---|
| 1 · Research | `agents/researcher.py` | Gemini brainstorms trending topics for your niche and outputs a structured brief |
| 2 · Script | `agents/scriptwriter.py` | Expands the brief into a narrated script with topic-locked video queries per section |
| 3 · Narration | `video/narrator.py` | Edge-TTS converts the script to a cinematic MP3 voiceover |
| 4 · Footage | `video/stock.py` | Finds and validates subject-relevant moving footage per section |
| 5 · Video | `video/creator.py` | Renders animated slides with Ken Burns, crossfades, captions, and music |
| 6 · Public upload | `uploader/youtube.py` | Uploads the rendered Short directly with `privacyStatus=public` |

---

## 📁 Project Structure

```
youtube-ai-agent/
├── 📄 pipeline.py              ← Run this to start the full pipeline
├── 🖥️  gui.py                  ← Run this for the visual GUI
├── ⚙️  config.py               ← All settings: keys, colors, voice, video
├── 📦  requirements.txt
├── 🔑  client_secret.json      ← YouTube OAuth (you add yours — see SETUP.md)
├── 📝  .env.example            ← Copy to .env and fill in your API keys
│
├── agents/
│   ├── gemini_client.py        ← Shared AI client with 8-model fallback chain
│   ├── researcher.py           ← Topic research agent
│   └── scriptwriter.py        ← Script writing agent
│
├── video/
│   ├── narrator.py             ← Edge-TTS voiceover generator
│   ├── stock.py                ← Pexels image downloader
│   ├── creator.py              ← Full video renderer (Ken Burns, captions, etc.)
│   └── music.py                ← Background music mixer
│
├── review/
│   ├── app.py                  ← Flask review server
│   └── templates/review.html  ← Review dashboard UI
│
├── uploader/
│   └── youtube.py              ← YouTube Data API v3 upload
│
├── gui_templates/
│   └── index.html              ← Full GUI (served by gui.py)
│
├── music library/              ← Drop your MP3/WAV tracks here
│
└── output/                     ← Auto-generated (gitignored)
    ├── research.json
    ├── script.json
    ├── narration.mp3
    ├── images/
    └── final_video.mp4
```

---

## 🤖 AI Model Fallback Chain

The system automatically tries models in order, rotating from your **Starting Model** preference:

```
gemini-2.5-flash  →  gemini-2.5-flash-lite  →  gemma-4-31b-it
       ↓
gemini-2.0-flash  →  gemini-2.0-flash-lite  →  gemma-3-27b-it
       ↓
gemini-1.5-flash-001  →  gemini-1.5-pro-001
```

If a model hits quota (429) or is overloaded (503), it automatically retries up to 3 times then advances to the next model — **so your pipeline never stops mid-run.**

Set your preferred starting model in the GUI under **Settings → AI Model**, or in `config.py`:

```python
GEMINI_MODEL = "gemini-3.5-flash-lite"   # preferred model; fallback includes free-tier 2.5 Flash-Lite when available
```

---

## 🔑 API Keys Required (All Free)

| Service | Key | Free Tier | Where to get it |
|---|---|---|---|
| **Google Gemini** | `GEMINI_API_KEY` | 1500 req/day | [aistudio.google.com](https://aistudio.google.com/apikey) |
| **Pexels** | `PEXELS_API_KEY` | 200 req/hour | [pexels.com/api](https://www.pexels.com/api/) |
| **Edge TTS** | *(none)* | Unlimited | Built-in |
| **YouTube API** | `client_secret.json` | Free | [Google Cloud Console](https://console.cloud.google.com) |
| **ElevenLabs** | `ELEVENLABS_API_KEY` | Optional | [elevenlabs.io](https://elevenlabs.io) |

> **Total cost: $0 per video.** All required services have free tiers that comfortably cover daily video production.

---

## 🎨 Customising Your Channel

Edit `config.py` to make the output yours:

```python
# 1. Describe your channel — the more specific, the better the topics
CHANNEL_DESCRIPTION = """
An educational channel covering the psychology of decision-making.
Target audience: adults 25-40 who enjoy Lex Fridman and Hidden Brain.
"""
CHANNEL_NAME = "Mind Mechanics"

# 2. Pick your voice
VOICE_ID = "en-GB-RyanNeural"   # British, deep, cinematic

# 3. Brand colours (RGB tuples)
COLORS = {
    "primary":   (99, 102, 241),   # your brand colour
    "highlight": (251, 191, 36),   # accent / titles
    ...
}

# 4. Video style
CROSSFADE_DURATION = 0.7   # image transition smoothness
OVERLAY_OPACITY    = 0.62  # how dark the image overlay is
```

---

## ❓ FAQ

<details>
<summary><b>Does this cost anything to run?</b></summary>

No. The entire stack uses free tiers:
- **Gemini** — 1500 req/day free on the 2.0-flash model
- **Pexels** — 200 req/hour free
- **Edge TTS** — completely free, no account needed
- **YouTube Data API** — free for uploads
- **Video rendering** — runs locally on your machine (CPU/GPU)

</details>

<details>
<summary><b>How long does one video take to generate?</b></summary>

On a mid-range machine (i7 + 16GB RAM):
- Research + Script: ~30 seconds
- Narration: ~10 seconds
- Image downloads: ~20 seconds
- Video render (10 min video): ~3–8 minutes depending on `RENDER_PRESET`
- Upload: ~2–5 minutes depending on internet speed

</details>

<details>
<summary><b>Can I use this without the YouTube upload?</b></summary>

Yes. Set `SKIP_YOUTUBE_UPLOAD=True` for a local validation run. GitHub Actions is configured to stage videos only and never upload them. The normal local pipeline opens a loopback-only fallback media system; rejection or interruption blocks upload.

</details>

<details>
<summary><b>Why is moviepy pinned to 1.0.3?</b></summary>

MoviePy v2.0 removed the `moviepy.editor` module and changed the entire API. v1.0.3 is required. Similarly, NumPy must be `<2.0.0` because MoviePy's underlying C extensions were compiled against NumPy 1.x. **Do not upgrade either.**

</details>

<details>
<summary><b>The video renders with tiny/ugly text</b></summary>

Your system is missing the fonts the renderer looks for. Install DejaVu fonts:
- **Ubuntu/Debian:** `sudo apt install fonts-dejavu`
- **Mac:** `brew install --cask font-dejavu-sans-mono-nerd-font`  
- **Windows:** fonts are already present in `C:/Windows/Fonts/`

</details>

<details>
<summary><b>YouTube upload fails with "access denied"</b></summary>

Delete `youtube_token.pickle` and re-run. This forces a fresh OAuth flow. Make sure your Google account is added as a **Test User** in Google Cloud Console → OAuth consent screen.

</details>

---


## Automatic YouTube upload schedule

GitHub Actions runs once per day at **7:00 PM IST** (13:30 UTC). Each workflow run attempts **two Shorts sequentially**, uploading both as **public** videos. If the first attempt fails, the workflow still tries the second Short and reports a failed job at the end if either attempt failed.

Media fallback order: Google Videos → Pexels Videos → Google Images → Pexels Images → locally generated gaming topic-card visuals. This keeps missing or unavailable stock media from being a hard stop when local fallback generation works. OAuth failures, API quota limits, YouTube outages, rendering failures, and other critical dependency failures can still prevent an upload.

Configure encrypted GitHub repository secrets: `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_REFRESH_TOKEN`, `GEMINI_API_KEY`, and any provider keys used by your configuration. The workflow validates YouTube OAuth before spending time rendering.



## 🗺️ Roadmap

- [ ] Thumbnail generator (AI-designed cover art)
- [x] Scheduler (GitHub Actions: daily 7 PM IST, two public Shorts attempts)
- [ ] Multi-channel support
- [ ] Custom intro/outro clips
- [ ] Analytics dashboard
- [ ] Voice cloning via ElevenLabs

---

## 🤝 Contributing

Pull requests are welcome! Please open an issue first to discuss major changes.

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit: `git commit -m 'Add my feature'`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 🌍 Made With This Tool

**[Eldritch Lore](https://www.youtube.com/@EldritchLore)** — science, history, and "what if" scenarios.
Running 100% on this pipeline. Subscribe to see it in action.

---

<div align="center">
Made with ❤️ by <a href="https://github.com/raunakpatil">@raunakpatil</a>
</div>



[![Star on GitHub](https://img.shields.io/github/stars/raunakpatil/youtube-agentic-ai-studio?style=social)](https://github.com/raunakpatil/youtube-agentic-ai-studio)

