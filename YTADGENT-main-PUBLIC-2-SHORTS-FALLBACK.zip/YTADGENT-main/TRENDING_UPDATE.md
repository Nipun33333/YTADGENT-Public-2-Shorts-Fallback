# Gaming Trend Discovery & Public Upload Update

The pipeline targets current US gaming topics: gaming news, lore, mechanics,
patches, glitches, speedruns, esports, game design, and gaming culture.

- Broad YouTube popularity signals are collected first.
- A gaming relevance gate filters unrelated candidates before semantic selection.
- Gemini performs semantic selection among eligible gaming candidates.
- The selected subject stays locked through research, script, visual queries, and rendering.
- Shorts scripts use a stronger opening hook, original explanatory commentary, and caution around rumors/datamined information.
- Human approval and staging gates have been removed from the upload path.
- Every upload is configured as public; stale `.env` privacy values cannot switch uploads to private.
- Media provider order is Google Videos, Pexels Videos, Google Images, and Pexels Images. Provider exceptions are caught so the next provider can be tried.
- If all external visual sources fail, the pipeline generates local gaming topic-card visuals so media discovery can continue.
- GitHub Actions runs once daily at 7:00 PM IST and attempts two Shorts sequentially. If the first attempt fails, it still tries the second.
- YouTube OAuth is validated before rendering. Invalid credentials, quota exhaustion, platform outages, or critical render errors can still prevent publishing.

YouTube monetization is not guaranteed. Use original commentary, verify claims,
and only use footage you have the right to use.
